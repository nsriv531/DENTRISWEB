<?php

if (isset($_GET["id"])) {
    $id = $_GET["id"];
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "test";

    $connection = new mysqli($servername, $username, $password, $database);
    $sql = "DELETE FROM main_table WHERE ins_comp_name = '$id'";
    $connection->query($sql);
}
header("location: /dentrisweb/mainindex.php");
exit;
?>

